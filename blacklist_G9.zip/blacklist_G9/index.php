<?php
// index.php
session_start();
require_once 'db/conn.php';
require_once 'includes/header.php';

$conn = getConnection();
$latest_products = [];

try {

    $stmt_latest = $conn->query("SELECT id, name, price, image FROM products ORDER BY id DESC LIMIT 8");
    $latest_products = $stmt_latest->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {

}
?>

    <div class="container-fluid p-0">
        <div class="banner-area text-white d-flex align-items-end justify-content-start">
            <div class="p-5"> <h1 class="display-3 fw-bold mb-3">BLACK LIST STORE</h1>
                <a href="categories.php" class="btn btn-warning btn-lg">Shop Now</a>
            </div>
        </div>
    </div>

    <div class="container-fluid p-0 my-5">
        <div class="brand-showcase p-5">
            <h3 class="display-5 fw-bold mb-4 text-center text-dark">ABOUT OUR BRAND</h3>

            <div class="row justify-content-center">
                <div class="col-md-10 text-center">
                    <p class="lead text-secondary" style="font-weight: 500;">
                        BLACK LIST is more than just a streetwear brand; it is a movement. Founded on the principle of bold, unapologetic expression, we specialize in dark, exclusive designs including premium hoodies, high-quality t-shirts, and limited-edition drops. Every piece is crafted to the highest standard, offering not just clothing, but an identity. Join the list and wear your story.
                    </p>
                </div>
            </div>
        </div>
    </div>


    <div class="container my-5">

        <h3 class="mb-4 text-center border-bottom pb-2">LATEST DROPS</h3>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4 mb-5">
            <?php if ($latest_products): ?>
                <?php foreach ($latest_products as $product): ?>
                    <div class="col">
                        <div class="card h-100 product-card text-center">
                            <img src="assets/img/<?= htmlspecialchars($product['image']) ?>" class="card-img-top" style="height: 250px; object-fit: cover;">
                            <div class="card-body">
                                <h6 class="card-title"><?= htmlspecialchars($product['name']) ?></h6>
                                <p class="card-text fw-bold"><?= number_format($product['price'], 2) ?> SAR</p>
                                <a href="product_details.php?id=<?= $product['id'] ?>" class="btn btn-sm btn-dark">View</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center w-100 alert alert-info">No products are currently available.</p>
            <?php endif; ?>
        </div>

        <h3 class="mb-4 text-center border-bottom pb-2">SHOP BY CATEGORY</h3>

        <div class="category-showcase-frame p-4 rounded-3 shadow-lg mb-5">
            <div class="row row-cols-md-3 g-3 text-center">
                <div class="col">
                    <a href="products.php?category=hoodie" class="category-link p-4 d-block rounded-3 shadow-sm">
                        <i class="fas fa-tshirt fa-2x mb-2"></i>
                        <p class="mb-0 fw-bold">HOODIES</p>
                    </a>
                </div>
                <div class="col">
                    <a href="products.php?category=tshirt" class="category-link p-4 d-block rounded-3 shadow-sm">
                        <i class="fas fa-tshirt fa-2x mb-2"></i>
                        <p class="mb-0 fw-bold">T-SHIRTS</p>
                    </a>
                </div>
                <div class="col">
                    <a href="products.php?category=giftcard" class="category-link p-4 d-block rounded-3 shadow-sm">
                        <i class="fas fa-gift fa-2x mb-2"></i>
                        <p class="mb-0 fw-bold">GIFT CARDS</p>
                    </a>
                </div>
            </div>
        </div>
    </div>

<?php
require_once 'includes/footer.php';
?>