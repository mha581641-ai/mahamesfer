<?php

session_start();
require_once 'includes/header.php';

$conn = getConnection();
$message = '';


$product_id = $_GET['id'] ?? null;
if (!$product_id || !is_numeric($product_id)) {

    header("Location: products.php");
    exit;
}

try {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = :id");
    $stmt->bindParam(':id', $product_id, PDO::PARAM_INT);
    $stmt->execute();
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        $message = '<div class="alert alert-warning">عذراً، المنتج المطلوب غير موجود.</div>';
    }
} catch (PDOException $e) {
    $message = '<div class="alert alert-danger">خطأ في جلب بيانات المنتج.</div>';
    $product = null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $product) {
    $quantity = $_POST['quantity'] ?? 1;
    $size = $_POST['size'] ?? 'M';
    $session_id = session_id();

    if ($quantity < 1) {
        $message = '<div class="alert alert-warning">يجب أن تكون الكمية على الأقل 1.</div>';
    } else {
        try {

            $checkStmt = $conn->prepare("SELECT id, quantity FROM cart WHERE session_id = :session_id AND product_id = :product_id AND size = :size");
            $checkStmt->bindParam(':session_id', $session_id);
            $checkStmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
            $checkStmt->bindParam(':size', $size);
            $checkStmt->execute();
            $cartItem = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if ($cartItem) {

                $newQuantity = $cartItem['quantity'] + $quantity;
                $updateStmt = $conn->prepare("UPDATE cart SET quantity = :quantity WHERE id = :id");
                $updateStmt->bindParam(':quantity', $newQuantity, PDO::PARAM_INT);
                $updateStmt->bindParam(':id', $cartItem['id'], PDO::PARAM_INT);
                $updateStmt->execute();
            } else {

                $insertStmt = $conn->prepare("INSERT INTO cart (product_id, quantity, size, session_id) VALUES (:product_id, :quantity, :size, :session_id)");
                $insertStmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
                $insertStmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
                $insertStmt->bindParam(':size', $size);
                $insertStmt->bindParam(':session_id', $session_id);
                $insertStmt->execute();
            }


            header("Location: cart.php");
            exit;

        } catch (PDOException $e) {
            $message = '<div class="alert alert-danger">خطأ في الإضافة إلى سلة التسوق: ' . $e->getMessage() . '</div>';
        }
    }
}
?>

<?php echo $message; ?>

<?php if ($product): ?>
<div class="card shadow-lg border-0">
    <div class="row g-0">
        <div class="col-md-5">
            <img src="assets/img/<?= htmlspecialchars($product['image']) ?>"
                 class="img-fluid rounded-start"
                 alt="<?= htmlspecialchars($product['name']) ?>"
                 style="height: 100%; object-fit: cover;">
        </div>
        <div class="col-md-7">
            <div class="card-body p-5">
                <h1 class="card-title display-4 mb-3"><?= htmlspecialchars($product['name']) ?></h1>
                <p class="fs-5 fw-bold text-success mb-4"><?= number_format($product['price'], 2) ?> ر.س</p>
                <p class="card-text border-top pt-3"><?= htmlspecialchars($product['description']) ?></p>

                <ul class="list-group list-group-flush mb-4"><li class="list-group-item"><strong>الفئة:</strong> <?= htmlspecialchars($product['category']) ?></li>
                    <li class="list-group-item"><strong>اللون:</strong> <?= htmlspecialchars($product['color']) ?></li>
                    <li class="list-group-item"><strong>متوفرة بالأحجام:</strong> <?= htmlspecialchars($product['size_options']) ?></li>
                </ul>

                <form method="POST" action="product_details.php?id=<?= $product['id'] ?>" class="mt-4">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="size" class="form-label">الحجم (Selection)</label>
                            <select class="form-select" id="size" name="size" required>
                                <?php
                                // يتم تقسيم خيارات الحجم وعرضها في قائمة منسدلة
                                $sizes = explode(',', $product['size_options']);
                                foreach ($sizes as $size_option):
                                    ?>
                                    <option value="<?= trim($size_option) ?>"><?= trim($size_option) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="quantity" class="form-label">الكمية</label>
                            <input type="number" class="form-control" id="quantity" name="quantity" value="1" min="1" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg w-100">
                        🛒 أضف إلى سلة التسوق
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
require_once 'includes/footer.php';
?>