</div>
</main>

<footer class="mt-auto main-footer">
    <div class="container d-flex justify-content-between align-items-center py-2">

        <p class="mb-0 footer-copyright">
            &copy; 2025 Blacklist Store. All Rights Reserved
        </p>

        <div class="footer-accounts d-flex align-items-center">

                <span class="mx-2 footer-account-item">
                    Email: <a href="mailto:black11@gmail.com" class="footer-link-dark">black11@gmail.com</a>
                </span>

            <span class="mx-2 footer-account-item d-none d-md-inline">
                    WhatsApp: <a href="https://wa.me/966506991982" class="footer-link-dark">0506991982</a>
                </span>

            <span class="mx-2 footer-account-item d-none d-md-inline">
                    Instagram: <a href="https://www.instagram.com/black.7" class="footer-link-dark">@black.7</a>
                </span>

            <span class="mx-2 footer-account-item d-none d-lg-inline">
                    Snapchat: <a href="https://www.snapchat.com/add/black.7" class="footer-link-dark">@black.7</a>
                </span>

        </div>

    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>