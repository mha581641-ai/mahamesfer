<?php

session_start();

require_once 'db/conn.php';
require_once 'includes/header.php';

$conn = getConnection();
$message = '';
$session_id = session_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
    $cart_id = $_POST['cart_id'] ?? null;
    $quantity = $_POST['quantity'] ?? 1;

    if ($cart_id && $quantity > 0) {
        try {
            $stmt = $conn->prepare("UPDATE cart SET quantity = :quantity WHERE id = :id AND session_id = :session_id");
            $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
            $stmt->bindParam(':id', $cart_id, PDO::PARAM_INT);
            $stmt->bindParam(':session_id', $session_id);
            $stmt->execute();
            $message = '<div class="alert alert-success alert-dismissible fade show" role="alert">تم تحديث كمية المنتج بنجاح. <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        } catch (PDOException $e) {
            $message = '<div class="alert alert-danger alert-dismissible fade show" role="alert">خطأ في تحديث الكمية. <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        }
    } else if ($quantity <= 0) {
        header("Location: cart.php?action=remove&cart_id=" . $cart_id);
        exit;
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'remove' && isset($_GET['cart_id'])) {
    $cart_id = $_GET['cart_id'];
    try {
        $stmt = $conn->prepare("DELETE FROM cart WHERE id = :id AND session_id = :session_id");
        $stmt->bindParam(':id', $cart_id, PDO::PARAM_INT);
        $stmt->bindParam(':session_id', $session_id);
        $stmt->execute();
        $message = '<div class="alert alert-info alert-dismissible fade show" role="alert">تم حذف المنتج من السلة بنجاح. <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        // إزالة معاملات الاستعلام من الرابط
        header("Location: cart.php");
        exit;
    } catch (PDOException $e) {
        $message = '<div class="alert alert-danger alert-dismissible fade show" role="alert">خطأ في حذف المنتج. <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
    }
}


$cartItems = [];
$totalPrice = 0;

try {
    $stmt = $conn->prepare("SELECT c.id as cart_id, c.quantity, c.size, p.id as product_id, p.name, p.price, p.image FROM cart c JOIN products p ON c.product_id = p.id WHERE c.session_id = :session_id ORDER BY c.added_at DESC");
    $stmt->bindParam(':session_id', $session_id);
    $stmt->execute();
    $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);


    foreach ($cartItems as $item) {
        $totalPrice += ($item['price'] * $item['quantity']);
    }

} catch (PDOException $e) {
    $message = '<div class="alert alert-danger alert-dismissible fade show" role="alert">خطأ في جلب بيانات سلة التسوق. <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
}
?>

<div class="container my-5">
    <?= $message ?>
    <h2 class="mb-5 text-center text-dark"> Checkout Summry</h2>

    <?php if (empty($cartItems)): ?>
        <div class="alert alert-info text-center" role="alert">
            سلة التسوق فارغة حالياً. <a href="products.php" class="alert-link">تصفح منتجاتنا!</a>
        </div>
    <?php else: ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="table-responsive cart-table-container mb-5">
                <table class="table table-bordered table-striped align-middle bg-white text-dark shadow-sm">
                    <thead class="bg-dark text-white">
                    <tr>
                        <th class="text-center" style="width: 10%;">Image</th>
                        <th style="width: 25%;">Product Name</th><th class="text-center" style="width: 10%;">Size</th>
                        <th class="text-center" style="width: 10%;">Price (SAR)</th>
                        <th class="text-center" style="width: 20%;">Quantity & Update</th>
                        <th class="text-center" style="width: 15%;">Subtotal</th>
                        <th class="text-center" style="width: 10%;">Remove</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($cartItems as $item): ?>
                        <tr class="cart-row">
                            <td class="text-center">
                                <img src="assets/img/<?= htmlspecialchars($item['image']) ?>"
                                     class="img-fluid cart-table-thumb"
                                     alt="<?= htmlspecialchars($item['name']) ?>">
                            </td>
                            <td>
                                <a href="product_details.php?id=<?= $item['product_id'] ?>" class="text-dark fw-bold text-decoration-none">
                                    <?= htmlspecialchars($item['name']) ?>
                                </a>
                            </td>
                            <td class="text-center"><?= htmlspecialchars($item['size']) ?></td>
                            <td class="text-center"><?= number_format($item['price'], 2) ?></td>

                            <td class="text-center">
                                <form method="POST" action="cart.php" class="d-flex justify-content-center align-items-center">
                                    <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">
                                    <input type="number"
                                           name="quantity"
                                           value="<?= $item['quantity'] ?>"
                                           min="1"
                                           class="form-control form-control-sm text-center"
                                           style="width: 70px;">
                                    <button type="submit" name="update_cart" class="btn btn-sm btn-outline-dark-admin update-btn ms-2" title="تحديث الكمية">
                                        <i class="fas fa-sync-alt"></i> تحديث
                                    </button>
                                </form>
                            </td>
                            <td class="text-center fw-bold text-success"><?= number_format($item['price'] * $item['quantity'], 2) ?></td>

                            <td class="text-center">
                                <a href="cart.php?action=remove&cart_id=<?= $item['cart_id'] ?>"
                                   class="btn btn-sm btn-outline-danger-admin remove-btn"
                                   title="حذف المنتج"
                                   onclick="return confirm('هل أنت متأكد من حذف هذا المنتج؟');">
                                    <i class="fas fa-trash-alt"></i> حذف المنتج
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card p-4 order-summary-card shadow-lg">
                <h4 class="mb-4 fw-bold text-dark border-bottom pb-2">ملخص الطلب</h4>

                <div class="d-flex justify-content-between mb-3">
                    <p class="text-muted mb-0">الإجمالي الفرعي:</p>
                    <p class="fw-bold mb-0 text-dark"><?= number_format($totalPrice, 2) ?> ر.س</p>
                </div>

                <div class="d-flex justify-content-between mb-4 border-top pt-3"><h5 class="fw-bold text-dark mb-0">الإجمالي الكلي:</h5>
                    <h5 class="fw-bold text-success mb-0 display-6"><?= number_format($totalPrice, 2) ?> ر.س</h5>
                </div>

                <a href="checkout.php" class="btn btn-success btn-lg checkout-btn w-100">
                    <i class="fas fa-check-circle me-2"></i> متابعة الدفع (Checkout)
                </a>
            </div>
        </div>
        </div> <?php endif; ?>
</div>

<?php
require_once 'includes/footer.php';
?>