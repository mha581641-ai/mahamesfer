<?php

require_once 'includes/header.php';
?>

    <h2 class="mb-5 text-center">Choose Category</h2>

    <div class="list-group shadow-lg">
        <a href="products.php?category=hoodie" class="list-group-item list-group-item-action category-item category-hoodie p-4 mb-2 rounded-3">
            <div class="d-flex w-100 justify-content-between align-items-center">
                <h4 class="mb-1 text-white">Hoodies</h4>
                <small class="text-white-50">4 colors</small>
            </div>
        </a>

        <a href="products.php?category=tshirt" class="list-group-item list-group-item-action category-item category-tshirt p-4 mb-2 rounded-3">
            <div class="d-flex w-100 justify-content-between align-items-center">
                <h4 class="mb-1 text-white">T-Shirts</h4>
                <small class="text-white-50">4 colors</small>
            </div>
        </a>

        <a href="products.php?category=giftcard" class="list-group-item list-group-item-action category-item category-giftcard p-4 mb-2 rounded-3">
            <div class="d-flex w-100 justify-content-between align-items-center">
                <h4 class="mb-1 text-white">Gift Cards</h4>
                <small class="text-white-50">Special drops</small>
            </div>
        </a>

        <a href="products.php" class="list-group-item list-group-item-action category-item category-all p-4 rounded-3">
            <div class="d-flex w-100 justify-content-between align-items-center">
                <h4 class="mb-1 text-white">All Products</h4>
                <small class="text-white-50">Shop everything</small>
            </div>
        </a>
    </div>

<?php
require_once 'includes/footer.php';
?>