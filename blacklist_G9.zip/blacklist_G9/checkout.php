<?php
// checkout.php
session_start();
require_once 'db/conn.php';
require_once 'includes/header.php';

$conn = getConnection();
$message = '';
$session_id = session_id();
$totalPrice = 0;


$cartItems = [];
try {
    $stmt = $conn->prepare("SELECT c.id as cart_id, c.quantity, c.size, p.id as product_id, p.name, p.price, p.image FROM cart c JOIN products p ON c.product_id = p.id WHERE c.session_id = :session_id");
    $stmt->bindParam(':session_id', $session_id);
    $stmt->execute();
    $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($cartItems)) {
        header("Location: cart.php");
        exit;
    }

    foreach ($cartItems as $item) {
        $totalPrice += ($item['price'] * $item['quantity']);
    }
} catch (PDOException $e) {
    $message = '<div class="alert alert-danger">خطأ في جلب بيانات سلة التسوق.</div>';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($cartItems)) {
    $customer_name = trim($_POST['customer_name'] ?? '');
    $customer_phone = trim($_POST['customer_phone'] ?? '');
    $customer_address = trim($_POST['customer_address'] ?? '');

    // تم تصحيح مشكلة دمج الـ empty باستخدام ||
    if (empty($customer_name)||empty($customer_phone)||empty($customer_address)) {
        $message = '<div class="alert alert-warning">الرجاء تعبئة جميع الحقول المطلوبة (الاسم، الهاتف، العنوان).</div>';
    } else {
        $conn->beginTransaction();
        try {
            // ✅ التصحيح: تم تغيير 'order_status' إلى 'status'
            $orderStmt = $conn->prepare("INSERT INTO orders (customer_name, customer_phone, customer_address, total, status) VALUES (:name, :phone, :address, :total, 'pending')");
            $orderStmt->bindParam(':name', $customer_name);
            $orderStmt->bindParam(':phone', $customer_phone);
            $orderStmt->bindParam(':address', $customer_address);
            $orderStmt->bindParam(':total', $totalPrice);
            $orderStmt->execute();

            $order_id = $conn->lastInsertId();

            $itemStmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price, size) VALUES (:order_id, :product_id, :quantity, :price, :size)");

            foreach ($cartItems as $item) {
                $itemStmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
                $itemStmt->bindParam(':product_id', $item['product_id'], PDO::PARAM_INT);
                $itemStmt->bindParam(':quantity', $item['quantity'], PDO::PARAM_INT);
                $itemStmt->bindParam(':price', $item['price']);
                $itemStmt->bindParam(':size', $item['size']);
                $itemStmt->execute();
            }


            $deleteStmt = $conn->prepare("DELETE FROM cart WHERE session_id = :session_id");
            $deleteStmt->bindParam(':session_id', $session_id);
            $deleteStmt->execute();

            $conn->commit();

            header("Location: success.php?order_id=" . $order_id);
            exit;

        } catch (PDOException $e) {
            $conn->rollBack();
            $message = '<div class="alert alert-danger">فشل في إتمام الطلب: ' . $e->getMessage() . '</div>';
        }
    }
}
?>

<div class="container my-5">
    <h1 class="text-center">Secure Checkout</h1>

    <?= $message ?>

    <div class="row justify-content-center">
        <div class="col-lg-8">

            <div class="order-summary-card p-4 mb-5">

                <ul class="list-group list-group-flush mb-4">
                    <?php foreach ($cartItems as $item): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center bg-transparent text-dark border-bottom">
                        <div class="d-flex align-items-center me-auto"><img src="assets/img/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>" class="admin-thumb me-3">
                            <div>
                                <p class="mb-0 fw-bold"><?= htmlspecialchars($item['name']) ?> (<?= htmlspecialchars($item['size']) ?>)</p><small class="text-muted d-block">السعر: <?= number_format($item['price'], 2) ?> ر.س | الكمية: <?= $item['quantity'] ?></small> </div>
                        </div>
                        <span class="fw-bold"><?= number_format($item['price'] * $item['quantity'], 2) ?> ر.س</span>
                    </li>
                    <?php endforeach; ?>
                </ul>

                <div class="d-flex justify-content-between align-items-center fw-bold text-dark border-top pt-3">
                    <span class="fs-5">الإجمالي الكلي:</span>
                    <span class="fs-4 text-success"><?= number_format($totalPrice, 2) ?> ر.س</span>
                </div>

            </div>
        </div>

        <div class="col-lg-8">
            <h4 class="mb-3 text-dark">بيانات الشحن</h4>
            <div class="card shadow-sm mb-5 p-4">
                <form method="POST" action="checkout.php">
                    <div class="mb-3">
                        <label for="customer_name" class="form-label text-dark">الاسم بالكامل</label>
                        <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?= htmlspecialchars($_POST['customer_name'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="customer_phone" class="form-label text-dark">رقم الهاتف</label>
                        <input type="text" class="form-control" id="customer_phone" name="customer_phone" value="<?= htmlspecialchars($_POST['customer_phone'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="customer_address" class="form-label text-dark">العنوان المفصل (المدينة، الشارع، المنزل)</label>
                        <textarea class="form-control" id="customer_address" name="customer_address" rows="3" required><?= htmlspecialchars($_POST['customer_address'] ?? '') ?></textarea>
                    </div>

                    <div class="mt-4">
                        <p class="fw-bold text-dark">طريقة الدفع:</p>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_method" id="cash_on_delivery" value="cash" checked>
                            <label class="form-check-label text-dark" for="cash_on_delivery">
                                الدفع عند الاستلام
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="btn checkout-btn btn-lg w-100 mt-4">
                        إتمام الطلب الآن
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
require_once 'includes/footer.php';
?>