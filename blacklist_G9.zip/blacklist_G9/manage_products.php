<?php

session_start();
require_once 'includes/header.php';

$conn = getConnection();

$message = '';
$action = $_GET['action'] ?? 'list';
$product_id = $_GET['id'] ?? null;


$product = [
        'id' => '',
        'name' => '',
        'category' => '',
        'color' => '',
        'price' => '',
        'image' => '',
        'description' => '',
        'size_options' => 'S, M, L, XL'
];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $color = trim($_POST['color'] ?? '');
    $price = trim($_POST['price'] ?? 0);
    $image = trim($_POST['image'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $size_options = trim($_POST['size_options'] ?? 'S, M, L, XL');

    $is_valid = true;
    if (empty($name)||empty($category)||empty($price)||empty($image)) {
        $message = '<div class="alert alert-danger">الرجاء تعبئة الحقول الأساسية (الاسم، الفئة، السعر، الصورة).</div>';
        $is_valid = false;
    }

    if ($is_valid) {
        if ($action === 'add') {
            try {
                $stmt = $conn->prepare("INSERT INTO products (name, category, color, price, image, description, size_options) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $category, $color, $price, $image, $description, $size_options]);
                $message = '<div class="alert alert-success">تمت إضافة المنتج بنجاح.</div>';
                header("Location: manage_products.php?action=list");
                exit;
            } catch (PDOException $e) {
                $message = '<div class="alert alert-danger">خطأ في الإضافة: ' . $e->getMessage() . '</div>';
            }
        } elseif ($action === 'edit' && $product_id) {
            try {
                $stmt = $conn->prepare("UPDATE products SET name=?, category=?, color=?, price=?, image=?, description=?, size_options=? WHERE id=?");
                $stmt->execute([$name, $category, $color, $price, $image, $description, $size_options, $product_id]);
                $message = '<div class="alert alert-success">تم تحديث المنتج بنجاح.</div>';
                header("Location: manage_products.php?action=list");
                exit;
            } catch (PDOException $e) {
                $message = '<div class="alert alert-danger">خطأ في التحديث: ' . $e->getMessage() . '</div>';
            }
        }
    }
}

if ($action === 'delete' && $product_id) {
    try {
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $message = '<div class="alert alert-info">تم حذف المنتج بنجاح.</div>';
        header("Location: manage_products.php?action=list");
        exit;
    } catch (PDOException $e) {
        $message = '<div class="alert alert-danger">خطأ في الحذف: ' . $e->getMessage() . '</div>';
        $action = 'list';
    }
}


if ($action === 'edit' && $product_id) {
    try {
        $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $fetched_product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($fetched_product) {
            $product = $fetched_product;
        } else {
            $message = '<div class="alert alert-warning">عذراً، المنتج المطلوب غير موجود.</div>';
            $action = 'list';
        }
    } catch (PDOException $e) {
        $message = '<div class="alert alert-danger">خطأ في جلب بيانات المنتج.</div>';
        $action = 'list';
    }
}


$products = [];
if ($action === 'list') {
    try {
        $stmt = $conn->query("SELECT * FROM products ORDER BY id DESC");
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {$message = '<div class="alert alert-danger">خطأ في جلب قائمة المنتات: ' . $e->getMessage() . '</div>';
    }
}

echo $message;
?>

    <h2 class="mb-4">
        <?php
        if ($action === 'add') echo 'إضافة منتج جديد';
        elseif ($action === 'edit') echo 'تعديل المنتج: ' . htmlspecialchars($product['name']);
        else echo 'All Products (Admin List)';
        ?>
    </h2>

<?php if ($action === 'add'||$action === 'edit'): ?>
<div class="card shadow-sm p-4">
    <form method="POST" action="manage_products.php?action=<?= $action ?><?= $product_id ? '&id=' . $product_id : '' ?>">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="name" class="form-label">اسم المنتج</label>
                <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>
            </div>

            <div class="col-md-3 mb-3">
                <label for="category" class="form-label">الفئة</label>
                <select class="form-select" id="category" name="category" required>
                    <option value="">اختر الفئة</option>
                    <option value="hoodie" <?= ($product['category'] === 'hoodie') ? 'selected' : '' ?>>Hoodie</option>
                    <option value="tshirt" <?= ($product['category'] === 'tshirt') ? 'selected' : '' ?>>T-Shirt</option>
                    <option value="giftcard" <?= ($product['category'] === 'giftcard') ? 'selected' : '' ?>>Gift Card</option>
                </select>
            </div>

            <div class="col-md-3 mb-3">
                <label for="color" class="form-label">اللون</label>
                <input type="text" class="form-control" id="color" name="color" value="<?= htmlspecialchars($product['color']) ?>" placeholder="white, black, etc.">
            </div>

            <div class="col-md-4 mb-3">
                <label for="price" class="form-label">السعر (SAR)</label>
                <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?= htmlspecialchars($product['price']) ?>" required>
            </div>

            <div class="col-md-8 mb-3">
                <label for="image" class="form-label">مسار الصورة</label>
                <input type="text" class="form-control" id="image" name="image" value="<?= htmlspecialchars($product['image']) ?>" placeholder="مثال: hoodies/black_hoodie.jpg" required>
            </div>

            <div class="col-md-12 mb-3">
                <label for="size_options" class="form-label">خيارات الأحجام (مفصولة بفاصلة)</label>
                <input type="text" class="form-control" id="size_options" name="size_options" value="<?= htmlspecialchars($product['size_options']) ?>" placeholder="S, M, L, XL" required>
            </div>

            <div class="col-md-12 mb-3">
                <label for="description" class="form-label">الوصف</label>
                <textarea class="form-control" id="description" name="description" rows="3"><?= htmlspecialchars($product['description']) ?></textarea>
            </div>
        </div>

        <button type="submit" class="btn btn-primary btn-lg mt-3">
            <?= ($action === 'add') ? 'إضافة المنتج' : 'حفظ التعديلات' ?>
        </button>
        <a href="manage_products.php" class="btn btn-secondary mt-3">إلغاء</a>
    </form>
</div>

<?php elseif ($action === 'list'): ?>
    <a href="manage_products.php?action=add" class="btn btn-dark mb-3">إضافة منتج جديد</a>

<div class="table-responsive">
    <table class="table table-striped table-hover shadow-sm">
        <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Color</th>
            <th>Price</th>
            <th>Image</th>
            <th>Actions</th></tr>
        </thead>
        <tbody>
        <?php if ($products): ?>
            <?php foreach ($products as $item): ?>
        <tr>
            <td><?= htmlspecialchars($item['id']) ?></td>
            <td><?= htmlspecialchars($item['name']) ?></td>
            <td><?= htmlspecialchars($item['category']) ?></td>
            <td><?= htmlspecialchars($item['color']) ?></td>
            <td><?= number_format($item['price'], 2) ?> SAR</td>
            <td><?= htmlspecialchars($item['image']) ?></td>
            <td style="width: 150px;">
                <a href="manage_products.php?action=edit&id=<?= $item['id'] ?>" class="btn btn-sm btn-info text-white me-1">Edit</a>
                <a href="manage_products.php?action=delete&id=<?= $item['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من حذف المنتج؟');">Delete</a>
            </td>
        </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7" class="text-center">لا يوجد منتجات مسجلة بعد.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php endif; ?>

<?php
require_once 'includes/footer.php';
?>