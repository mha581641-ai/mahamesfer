<?php
require_once 'includes/header.php';

$order_id = $_GET['order_id'] ?? null;
?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-center shadow-lg border-success">
                <div class="card-header bg-success text-white">
                    <h1 class="display-4">🎉 تم الطلب بنجاح!</h1>
                </div>
                <div class="card-body p-5">
                    <p class="lead">
                        شكرًا لك على ثقتك بمتجر Blacklist. لقد تم استلام طلبك بنجاح.
                    </p>
                    <?php if ($order_id): ?>
                        <div class="alert alert-success d-inline-block p-3">
                            <h4 class="alert-heading">رقم طلبك هو: #<?= htmlspecialchars($order_id) ?></h4>
                        </div>
                        <p class="text-muted">
                            يمكنك تتبع حالة طلبك باستخدام هذا الرقم (الحالة الافتراضية: قيد الانتظار).
                        </p>
                    <?php else: ?>
                        <p class="text-danger">
                            حدث خطأ في عرض رقم الطلب، لكن الطلب مسجل في النظام.
                        </p>
                    <?php endif; ?>

                    <hr>
                    <a href="products.php" class="btn btn-primary btn-lg mt-3">العودة للتسوق</a>
                </div>
            </div>
        </div>
    </div>

<?php
require_once 'includes/footer.php';
?>