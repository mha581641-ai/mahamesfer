<?php

require_once 'includes/header.php';

$conn = getConnection();
$limit = 6;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// معلمات الفلترة
$category = $_GET['category'] ?? '';
$color = $_GET['color'] ?? '';

$where_clauses = [];
$params = [];
$param_types = [];

if (!empty($category) && $category !== 'all') {
    $where_clauses[] = "category = ?";
    $params[] = $category;
    $param_types[] = 's';
}

if (!empty($color) && $color !== 'all') {
    $where_clauses[] = "color = ?";
    $params[] = $color;
    $param_types[] = 's';
}

$where_sql = count($where_clauses) > 0 ? " WHERE " . implode(" AND ", $where_clauses) : "";

$totalStmt = $conn->prepare("SELECT COUNT(*) FROM products" . $where_sql);
$totalStmt->execute($params);
$totalProducts = $totalStmt->fetchColumn();
$totalPages = ceil($totalProducts / $limit);


$sql = "SELECT id, name, price, image, description FROM products" . $where_sql . " LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

$stmt = $conn->prepare($sql);


$stmt->execute($params);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);


$all_categories = ['hoodie', 'tshirt', 'giftcard'];
$all_colors = ['white', 'black', 'blue', 'orange'];
?>

<h2 class="mb-4">Shop Products</h2>

<div class="card p-3 mb-5 shadow-sm">
    <form method="GET" action="products.php" class="row g-3 align-items-end">
        <div class="col-md-4">
            <label for="category_filter" class="form-label">Category</label>
            <select class="form-select" id="category_filter" name="category">
                <option value="all">All</option>
                <?php foreach ($all_categories as $cat): ?>
                    <option value="<?= $cat ?>" <?= ($category === $cat) ? 'selected' : '' ?>><?= ucfirst($cat) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label for="color_filter" class="form-label">Color</label>
            <select class="form-select" id="color_filter" name="color">
                <option value="all">All</option>
                <?php foreach ($all_colors as $col): ?>
                    <option value="<?= $col ?>" <?= ($color === $col) ? 'selected' : '' ?>><?= ucfirst($col) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-4">
            <button type="submit" class="btn btn-dark w-100">Filter</button>
        </div>
    </form>
</div>


<div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">
    <?php if ($products): ?>
        <?php foreach ($products as $product): ?>
            <div class="col">
                <div class="card h-100 product-card shadow-sm">
                    <img src="assets/img/<?= htmlspecialchars($product['image']) ?>"
                         class="card-img-top"
                         alt="<?= htmlspecialchars($product['name']) ?>"
                         style="height: 300px; object-fit: cover;">
                    <div class="card-body d-flex flex-column text-center">
                        <h5 class="card-title fw-bold"><?= htmlspecialchars($product['name']) ?></h5>
                        <p class="card-text text-muted flex-grow-1"><?= substr(htmlspecialchars($product['description']), 0, 30) ?>...</p>
                        <p class="card-text fs-5 fw-bold text-dark mt-auto"><?= number_format($product['price'], 2) ?> SAR</p>
                        <a href="product_details.php?id=<?= $product['id'] ?>" class="btn btn-primary mt-2">View</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p class="text-center w-100 alert alert-info">No products found matching your filter criteria.</p>
    <?php endif; ?>
</div><?php if ($totalPages > 1):
    // بناء رابط Pagination مع تضمين شروط الفلتر
    $filter_params = http_build_query(['category' => $category, 'color' => $color]);
    ?>
    <nav aria-label="Page navigation" class="mt-5">
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                    <a class="page-link" href="products.php?<?= $filter_params ?>&page=<?= $i ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
<?php endif; ?>

<?php
require_once 'includes/footer.php';
?>