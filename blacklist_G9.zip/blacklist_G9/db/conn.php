<?php
const DB_FILE = __DIR__ . '/c72_445035707.db';

function getConnection()
{
    try {

        $conn = new PDO("sqlite:" . DB_FILE);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $conn->exec('PRAGMA foreign_keys = ON;');
        return $conn;
    } catch (PDOException $e) {
        die("فشل الاتصال بقاعدة البيانات: " . $e->getMessage());
    }
}
